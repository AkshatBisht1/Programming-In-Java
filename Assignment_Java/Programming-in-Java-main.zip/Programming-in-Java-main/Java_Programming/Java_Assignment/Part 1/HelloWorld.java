public class HelloWorld {
/**
 * The main method that serves as the entry point for the program.
 * It prints "Hello, World!" to the standard output.
 * @param args command line arguments, not used in this program
 */

    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}

